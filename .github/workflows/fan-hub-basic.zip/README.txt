# 기본 팬 허브(초간단 배포판)
- 단일 `index.html` 파일만 사용합니다. (Google 로그인, 관리자 기능 없음)
- 기능: 멤버/최애, 팬아트(해시태그 타임라인), 커버곡, 일기/고백함(삭제), 투표(월 1표)

## 배포(가장 쉬운 방법 - GitHub Pages)
1) 새 리포 만들기 (Public 권장)
2) 리포 **루트**에 `index.html` 업로드
3) Settings → Pages → Source: Deploy from a branch / Branch: main / Folder: `/ (root)`
4) 루트에 **`.nojekyll`** 파일 하나 추가(내용 비워도 됨)
5) 배포 URL: `https://<사용자명>.github.io/<리포명>/`

## 팁
- React 등은 필요 없습니다.
- X 이미지는 프록시 없이 **타임라인 임베드**로만 표시합니다.
